Sky Survivor — AFTERBURN

HTML・JavaScript・CSS・Three.jsを同梱したゲーム一式です。

PCで起動する方法（Python 3がある場合）
1. ZIPを展開します。
2. 展開したフォルダーで次を実行します。
   python -m http.server 8000
3. ブラウザで http://localhost:8000 を開きます。

JavaScriptモジュールを使用するため、index.htmlの直接ダブルクリックでは動作しないことがあります。
Webサイトに配置する場合は、このフォルダー全体をアップロードしてください。
iPhoneでは公開URLをSafariで開いてプレイしてください。
https://sky-survivor-afterburn.cuichunxue1984.chatgpt.site

操作
左スティック：操縦／右：加速長押し・フレア
PC：WASDまたは矢印キー、Shiftで加速、Spaceでフレア
音あり・音なしは出撃前に選択できます。
右上の視点ボタンで操縦席／追尾を切り替えます。
一時停止画面で揺れを控えめにできます。

同梱のThree.jsのライセンスはvendor/LICENSEを参照してください。
